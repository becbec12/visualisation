-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2023 at 09:40 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kworldkaraoke`
--

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL,
  `invoice_date` date NOT NULL,
  `reservation_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `level_id` int(11) NOT NULL,
  `level_desc` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`level_id`, `level_desc`) VALUES
(1, 'admin'),
(2, 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservation_id` int(11) NOT NULL,
  `reserve_date` date DEFAULT NULL,
  `room_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `approval` int(11) DEFAULT NULL,
  `slot_id` varchar(20) DEFAULT NULL,
  `rmade_time` timestamp NULL DEFAULT current_timestamp(),
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `reserve_date`, `room_id`, `user_id`, `approval`, `slot_id`, `rmade_time`, `admin_id`) VALUES
(1, '2023-06-19', 'S101', 1, 0, '01', '2023-06-19 00:39:55', NULL),
(2, '2023-06-19', 'S101', 1, 0, '01', '2023-06-19 00:39:55', NULL),
(3, '2023-06-19', 'S101', 1, 0, '01', '2023-06-19 00:40:12', NULL),
(4, '2023-06-19', 'S101', 1, 0, '01', '2023-06-19 00:40:13', NULL),
(5, '2023-06-19', 'D102', 1, 0, '03', '2023-06-19 00:45:21', NULL),
(6, '2023-06-19', 'D102', 1, 0, '03', '2023-06-19 00:45:21', NULL),
(7, '2023-06-19', 'D101', 1, 0, '06', '2023-06-19 00:45:59', NULL),
(8, '2023-06-19', 'D101', 1, 0, '06', '2023-06-19 00:45:59', NULL),
(9, '2023-06-19', 'S103', 1, 0, '02', '2023-06-19 03:47:51', NULL),
(10, '2023-06-19', 'D101', 1, 0, '02', '2023-06-19 03:48:27', NULL),
(11, '2023-06-20', 'S101', 1, 0, '01', '2023-06-20 12:09:01', NULL),
(12, '2023-06-04', 'S101', 1, NULL, '01', '2023-06-20 12:18:00', NULL),
(13, '2023-06-20', 'S101', 1, NULL, '01', '2023-06-20 12:18:21', NULL),
(14, '2023-06-20', 'S101', 1, NULL, '02', '2023-06-20 15:49:35', NULL),
(15, '2023-06-19', 'S101', 1, NULL, '01', '2023-06-20 15:49:57', NULL),
(16, '2023-06-19', 'S101', 1, NULL, '06', '2023-06-20 15:50:24', NULL),
(17, '2023-07-03', 'S101', 1, NULL, '01', '2023-07-03 11:28:18', NULL),
(18, '2023-07-03', 'S101', 1, NULL, '01', '2023-07-03 11:28:43', NULL),
(19, '2023-07-03', 'S101', 1, NULL, '04', '2023-07-03 11:28:54', NULL),
(20, '2023-07-03', 'S101', 1, NULL, '01', '2023-07-03 11:29:29', NULL),
(21, '2023-07-03', 'S101', 1, NULL, '01', '2023-07-03 11:50:13', NULL),
(22, '2023-07-06', 'S101', 1, NULL, '01', '2023-07-03 11:55:17', NULL),
(23, '2023-07-03', 'S101', 1, NULL, '02', '2023-07-03 12:35:16', NULL),
(24, '2023-07-12', 'S101', 1, 1, '01', '2023-07-03 12:52:32', NULL),
(25, '2023-07-03', 'S101', 1, NULL, '03', '2023-07-03 12:53:05', NULL),
(26, '2023-07-03', 'S101', 1, NULL, '06', '2023-07-03 12:53:18', NULL),
(27, '2023-06-16', 'S101', 1, NULL, '01', '2023-07-03 13:37:11', NULL),
(28, '2023-07-02', 'S102', 1, NULL, '01', '2023-07-03 13:38:46', NULL),
(29, '2023-07-04', 'S102', 1, NULL, '01', '2023-07-03 13:39:10', NULL),
(30, '2023-07-02', 'S102', 1, NULL, '02', '2023-07-03 13:39:23', NULL),
(31, '2023-07-04', 'S102', 1, NULL, '03', '2023-07-03 13:40:18', NULL),
(32, '2023-07-03', 'S101', 1, NULL, '05', '2023-07-03 13:40:25', NULL),
(33, '2023-07-05', 'S101', 1, NULL, '01', '2023-07-03 13:41:07', NULL),
(34, '2023-07-04', 'S101', 1, NULL, '01', '2023-07-03 13:41:29', NULL),
(35, '2023-07-04', 'S101', 1, NULL, '02', '2023-07-03 13:42:47', NULL),
(36, '2023-07-04', 'S101', 1, NULL, '03', '2023-07-03 14:16:30', NULL),
(37, '2023-07-04', 'D101', 1, NULL, '01', '2023-07-04 00:18:04', NULL),
(38, '2023-07-04', 'S101', 1, NULL, '04', '2023-07-04 01:14:25', NULL),
(39, '2023-07-04', 'S101', 1, NULL, '05', '2023-07-04 01:14:51', NULL),
(40, '2023-07-04', 'D104', 1, NULL, '01', '2023-07-04 01:15:03', NULL),
(41, '2023-07-04', 'D101', 1, NULL, '02', '2023-07-04 01:16:06', NULL),
(42, '2023-07-04', 'D101', 1, NULL, '03', '2023-07-04 01:16:48', NULL),
(43, '2023-07-04', 'S103', 1, NULL, '01', '2023-07-04 01:16:52', NULL),
(44, '0000-00-00', 'S103', 1, NULL, '01', '2023-07-04 01:59:00', NULL),
(45, '2023-07-10', 'S101', 1, NULL, '01', '2023-07-10 00:22:38', NULL),
(46, '2023-07-10', 'S101', 1, 1, '02', '2023-07-10 01:34:58', NULL),
(47, '2023-07-10', 'S101', 1, 1, '03', '2023-07-10 03:17:52', NULL),
(48, '2023-07-10', 'S102', 1, NULL, '01', '2023-07-10 03:23:25', NULL),
(49, '2023-07-10', 'V101', 2, NULL, '06', '2023-07-10 03:29:37', NULL),
(50, '2023-07-12', 'S101', 1, NULL, '06', '2023-07-12 12:48:00', NULL),
(51, '2023-07-12', 'S101', 1, NULL, '02', '2023-07-12 12:48:35', NULL),
(52, '2023-07-11', 'S101', 1, NULL, '01', '2023-07-13 05:20:16', NULL),
(65, '2023-07-13', 'S101', 1, NULL, '01', '2023-07-13 05:34:33', NULL),
(66, '2023-07-13', 'S104', 1, NULL, '01', '2023-07-13 05:35:13', NULL),
(67, '2023-07-13', 'S101', 3, NULL, '02', '2023-07-13 05:36:03', NULL),
(68, '2023-07-13', 'S101', 3, NULL, '03', '2023-07-13 05:37:11', NULL),
(69, '2023-07-13', 'S101', 3, NULL, '04', '2023-07-13 05:43:30', NULL),
(70, '2023-07-13', 'S101', 3, NULL, '04', '2023-07-13 05:43:30', NULL),
(71, '2023-07-13', 'S101', 3, 0, '04', '2023-07-13 05:44:11', NULL),
(72, '2023-07-13', 'S101', 3, NULL, '04', '2023-07-13 05:44:11', NULL),
(73, '2023-07-13', 'S101', 3, NULL, '05', '2023-07-13 05:50:06', NULL),
(74, '2023-07-13', 'S101', 3, NULL, '06', '2023-07-13 05:50:37', NULL),
(77, '2023-07-14', 'S101', 3, 1, '01', '2023-07-13 05:53:56', NULL),
(78, '2023-07-13', 'D102', 3, 0, '01', '2023-07-13 05:55:45', NULL),
(79, '2023-07-13', 'D102', 3, NULL, '02', '2023-07-13 05:57:01', NULL),
(80, '2023-07-13', 'D102', 3, NULL, '03', '2023-07-13 05:57:08', NULL),
(87, '2023-07-13', 'D101', 3, NULL, '01', '2023-07-13 05:58:49', NULL),
(88, '2023-07-13', 'D101', 3, NULL, '02', '2023-07-13 06:06:19', NULL),
(89, '2023-07-13', 'D101', 3, NULL, '03', '2023-07-13 06:09:24', NULL),
(90, '2023-07-13', 'S104', 3, NULL, '02', '2023-07-13 06:11:50', NULL),
(91, '2023-07-13', 'V101', 3, NULL, '01', '2023-07-13 06:13:13', NULL),
(92, '2023-07-13', 'V101', 3, 1, '02', '2023-07-13 06:13:36', NULL),
(93, '2023-07-14', 'S101', 5, NULL, '02', '2023-07-13 06:24:51', NULL),
(94, '2023-07-29', 'D103', 6, 1, '01', '2023-07-13 06:35:32', NULL),
(95, '2023-07-14', 'S102', 7, 1, '01', '2023-07-13 07:12:30', NULL),
(96, '2023-07-13', 'S102', 2, 0, '01', '2023-07-13 07:16:32', NULL),
(97, '2023-07-13', 'V102', 8, NULL, '05', '2023-07-13 07:22:31', NULL),
(98, '2023-07-15', 'V104', 9, NULL, '06', '2023-07-13 07:27:53', NULL),
(99, '2023-07-14', 'V113', 11, NULL, '01', '2023-07-13 07:53:49', NULL),
(100, '2023-07-13', 'D101', 2, NULL, '04', '2023-07-13 08:00:19', NULL),
(101, '2023-07-13', 'V113', 12, NULL, '02', '2023-07-13 08:07:22', NULL),
(102, '2023-07-13', 'V113', 13, NULL, '01', '2023-07-13 09:17:07', NULL),
(103, '2023-07-19', 'D101', 1, NULL, '01', '2023-07-19 08:05:32', NULL),
(104, '2023-07-19', 'D101', 1, 1, '01', '2023-07-19 08:11:53', NULL),
(105, '2023-07-19', 'S103', 7, NULL, '01', '2023-07-19 13:04:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` varchar(255) NOT NULL,
  `room_type` varchar(255) DEFAULT NULL,
  `room_price` decimal(10,2) DEFAULT NULL,
  `room_no` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_type`, `room_price`, `room_no`) VALUES
('D101', 'deluxe', 35.00, '05'),
('D102', 'deluxe', 35.00, '06'),
('D103', 'deluxe', 35.00, '07'),
('D104', 'deluxe', 35.00, '08'),
('S101', 'standard', 20.00, '01'),
('S102', 'standard', 20.00, '02'),
('S103', 'standard', 20.00, '03'),
('S104', 'standard', 20.00, '04'),
('V101', 'vip', 55.00, '09'),
('V102', 'vip', 55.00, '10'),
('V103', 'vip', 55.00, '11'),
('V104', 'vip', 55.00, '12'),
('V113', 'vip', 55.00, '13'),
('V114', 'vip', 55.00, '14');

-- --------------------------------------------------------

--
-- Table structure for table `slot`
--

CREATE TABLE `slot` (
  `slot_id` varchar(20) NOT NULL,
  `slot` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slot`
--

INSERT INTO `slot` (`slot_id`, `slot`) VALUES
('01', '16:00-17:00'),
('02', '17:00-18:00'),
('03', '18:00-19:00'),
('04', '19:00-20:00'),
('05', '20:00-21:00'),
('06', '21:00-22:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_pswd` varchar(255) DEFAULT NULL,
  `user_fname` varchar(255) DEFAULT NULL,
  `user_lname` varchar(255) DEFAULT NULL,
  `user_dob` date DEFAULT NULL,
  `user_gender` char(1) DEFAULT NULL,
  `user_pnum` varchar(20) DEFAULT NULL,
  `level_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_pswd`, `user_fname`, `user_lname`, `user_dob`, `user_gender`, `user_pnum`, `level_id`) VALUES
(1, 'shaza', '111', 'shaza', 'ruddin', '2023-07-10', 'f', '01234566780', 1),
(2, 'shaza', '123', 'shaza', 'ruddin', '2023-07-10', 'f', '01234566780', 2),
(3, 'shaza', '123', 'shaza', 'ruddin', '2023-07-10', 'f', '01234566780', 2),
(4, 'shaza', '123', 'shaza', 'ruddin', '2023-07-10', 'f', '01234566780', 2),
(5, 'shaza', 'abc@1234', 'shaza', 'ruddin', '2023-07-10', 'f', '01234566780', 2),
(6, 'shaza', '123', 'shaza', 'ruddin', '2023-07-10', 'f', '01234566780', 2),
(7, 'awin', '111', 'nur', 'awin', '1992-06-09', 'f', '0134452121', 2),
(8, 'zulfah', '1234z', 'zulfah', 'athilah', '2003-10-24', 'f', '0166577063', 2),
(9, 'pcyder', 'd.omylove1', 'Chanyeol', 'Park', '2003-02-18', 'f', '0199676710', 2),
(11, 'nurin', 'n', 'nurin', 'nafeesa', '2003-11-05', 'f', '01155096838', 2),
(12, 'haha', '1231', 'hahahah', 'hahaa', '2023-07-02', 'm', '01111111111112332', 2),
(13, 'wankun', 'wanwan', 'wan', 'kun', '2003-03-18', 'm', '0163295866', 2),
(14, 'aimanzaku1', '123', 'aiman', 'zakuwan', '2023-07-20', 'm', '01139193026', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`),
  ADD KEY `reservation_id` (`reservation_id`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`level_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `addon_reserve_ibfk_3` (`user_id`),
  ADD KEY `FK_reservation_slot` (`slot_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `slot`
--
ALTER TABLE `slot`
  ADD PRIMARY KEY (`slot_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `level_id` (`level_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`reservation_id`);

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `FK_reservation_slot` FOREIGN KEY (`slot_id`) REFERENCES `slot` (`slot_id`),
  ADD CONSTRAINT `addon_reserve_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `room` (`room_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`level_id`) REFERENCES `level` (`level_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
