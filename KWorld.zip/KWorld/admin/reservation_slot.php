<?php

include('db.php');
include_once "header.html";
echo "<br>";
include ("../login/session.php");
if (!isset($_SESSION['username'])) {
       // header('Location: ../login');
        } 


?>
<!DOCTYPE html>
<html lang="en">

        <style>
table {

  width: 30%;
  background-color: #ffffff;
  border-collapse: collapse;
  border-width: 2px;
  border-color: #0F172B;
  border-style: solid;
  color: #000000;
  align:center;
  }

 td,  th {
text-align:center;
  border-width: 2px;
  border-color: #0F172B;
  border-style: solid;
  padding: 3px;
}

 thead {
  background-color: #FEA116;;
}

input[type="date"] {
  background-color: #FEA116;;
  outline: none;
      top: 50%;
    left: 50%;
}

input[type="date"]::-webkit-clear-button {
  font-size: 18px;
  height: 30px;
  position: absolute;
}

input[type="date"]::-webkit-inner-spin-button {
  height: 28px;
}

input[type="date"]::-webkit-calendar-picker-indicator {
  font-size: 15px;
}


</style>
       <?php

    //get the parameter
    $room_id=$_GET['id'];
    $mydate=$_GET['mydate'];

    //construct and run query to list vans
    $q="select * from room where room_id='".$_GET['id']."'";
    $res=mysqli_query($connection,$q);
    $r=mysqli_fetch_assoc($res);
    echo "<h2>Room ".$r['room_no']."</h2>\n";
    echo "<p>".$r['room_type']."\n".$r['room_price']."\n".$mydate."</p>\n";
    echo "<form method=get action=reservation_conf.php><input type=hidden name=id value=$room_id>"; //room type 
    echo "<input type=date align=center name=mydate><input type=submit></form>";

    $q="SELECT * FROM (SELECT * FROM reservation where (reserve_date='$mydate' and room_id='$room_id' and (approval=1 or approval is null))) a right join(select * from slot) b on a.slot_id=b.slot_id";

    //echo $q;


    $res=mysqli_query($connection,$q);
    echo "<table border=2 align=center>\n";
    echo "<thead><tr><th>Slot</th><th>Status</th><th>Action</th></tr></thead>\n";
    while($r=mysqli_fetch_assoc($res)){
        $class = '';
        echo "<tr><td>".$r['slot']."</td><td>";
        if(($r['rmade_time']!=null)&&($r['approval']==1)) echo '<a style="color:red">
      Not Available </a> '; 
        elseif($r['rmade_time']!=null&&($r['approval']==0 or $r['approval']==NULL)) echo '<span style="color:#FFE87C;">Pending</span> <a href=reservation_conf.php?room_id='.$room_id.'&slot_id='.$r['slot_id'].'&date='.$mydate.'></a>'; 
        else {
        echo '<a style="color:green">
      Available </a> ';
; 
        echo '<td><a href=reservation_conf.php?room_id='.$room_id.'&slot_id='.$r['slot_id'].'&date='.$mydate.'><button>Book</button></a></td>';
    }
        echo "</td></tr>\n";
    }
    echo "</table><br><br>";

    //construct and run query to list users 

    //clear results and close the connection



    //construct and run query to list users 

    //clear results and close the connection

    include_once "footer.html";
?>
</body>
</html>