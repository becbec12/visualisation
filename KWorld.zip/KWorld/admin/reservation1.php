<?php
include_once "db.php";
session_start();

include_once "header.html";
echo "<br>";
include_once "reservation_room.php";

include_once "footer.html";
?>