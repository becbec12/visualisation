<?php 
$dbconn = mysqli_connect("localhost","root","","kworldkaraoke");

$i=0;

foreach ( $_POST as $sForm => $value )
{
	$postedValue = htmlspecialchars( stripslashes( $value ), ENT_QUOTES ) ;
    $valuearr[$i] = $postedValue; 
$i++;
}

   $username = $_POST['username'];
   $password = $_POST['password'];
   $fname = $_POST['userfname'];
   $lname = $_POST['userlname'];
   $dob = $_POST['userdob'];
   $phoneno = $_POST['userphono'];
   $level_id = $_POST['level_id'];
   $gender=$_POST['gender'];
	$sql0 = "SELECT user_name FROM users WHERE user_name = '$valuearr[0]'";
	$query0 = mysqli_query($dbconn, $sql0) or die ("Error: " . mysqli_error($dbconn));
	$row0 = mysqli_num_rows($query0);
	
	if($row0 != 0){
	header('Location: indexrecordexist.html');
	echo "<b>Record is existed</b>";
	}
	else{
	/* execute SQL INSERT command */
	$sql2 = "INSERT INTO users (user_name, user_pswd,user_fname,user_lname,user_dob,user_gender,user_pnum,level_id)
	VALUES ('$valuearr[0]', '$valuearr[5]', '$valuearr[1]', '$valuearr[2]', '$valuearr[3]', '$valuearr[7]', '$valuearr[4]', '$valuearr[6]')";
		mysqli_query($dbconn, $sql2) or die ("Error: " . mysqli_error($dbconn));
	/* rediredt to respective page */
	header('Location: ..kworldkaraoke/admin');
	//echo "Data has been saved";
	}

	/* close db connection */
	mysqli_close($dbconn);


?>