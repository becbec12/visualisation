<?php
include_once "db.php";
session_start();

echo "<br>";
include_once "index.html";
?>