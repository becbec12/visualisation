                  <style>
                    .button-purple {
                    background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
                    border: none;
                    color: white;
                    padding: 10px 20px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                    border-radius: 10px;
                  }

                  table {
                    width: 70%;
                    background-color: #ffffff;
                    border-collapse: collapse;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                    color: #000000;
                    align:center;
                  }

                   td, th {
                    text-align:center;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                  }

                   thead {
                    background-color: #FEA116;;
                  }

                  .center {
                    margin-left: auto;
                    margin-right: auto;
                  }
                </style>

                  <?php

                  include "db.php";
                  include "header.html";

                  echo "<h1 style='font-family: Copperplate; text-align:center; color: #FEA1160;'>Manage User's Information</h1>";

                  echo "<div style='text-align:center; padding: 5px;'>";
                    echo "<form action='admin_list.php' method='post' style='display:inline-block;'>";
                      echo "<input type='submit' name='approve' value='Admin' class='button-purple'/>";
                    echo "</form>";
                    echo "<form action='customer.php' method='post' style='display:inline-block;'>";
                      echo "<input type='submit' name='approve' value='Customer' class='button-purple'/>";
                    echo "</form>";
                  echo "</div>";
                  echo "<br>";

                  echo "<div class='button'>";
                  echo "<form action='admin_mang/admin_index.php'>";
                    echo "<input type='submit' name='signup' value='Add'>";
                  echo "</div>";

                  $query = "SELECT * FROM users WHERE level_id = 1";
                  $result=mysqli_query($connection, $query);

                  $i = 1; //counter for the checkboxes so that each has a unique name
                  echo "<form action='reservation_process.php' method='post'>"; //form started here
                  echo "<table border='1' style='width: 100%;'border-collapse: collapse;'>";
                  echo "<tr style='background-color: #f2f2f2;'>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Admin ID</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Name</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Password</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Phone Number</th>";
                  echo "</tr>";

                  while($row = mysqli_fetch_array($result))
                  {
                      echo "<tr>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_id'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_name'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_pswd'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_pnum'] . "</td>";
                      echo "</tr>";
                      $i++;
                  }
                  echo "</table>";
                  echo "</form>";

                  mysqli_close($connection);

                  ?>