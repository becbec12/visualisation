<?php
include_once "db.php";
session_start();

include_once "header.html";

include_once "room_list.php";

include_once "footer.html";
?>