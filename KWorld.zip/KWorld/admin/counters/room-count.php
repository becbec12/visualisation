<?php 
    $connection = mysqli_connect("localhost","root","","kworldkaraoke");
    $sql = "SELECT * FROM room";
    $query = $connection->query($sql);

    echo "$query->num_rows";

?>