<?php 
    $connection = mysqli_connect("localhost","root","","kworldkaraoke");
    $sql = "SELECT * FROM reservation";
    $query = $connection->query($sql);

    echo "$query->num_rows";

?>