<?php 
    $connection = mysqli_connect("localhost","root","","kworldkaraoke");
    $sql = "SELECT * FROM users WHERE level_id = '1'";
    $query = $connection->query($sql);

    echo "$query->num_rows";

?>