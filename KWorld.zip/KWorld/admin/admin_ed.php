
<style>
    .button-purple {
                    background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
                    border: none;
                    color: white;
                    padding: 10px 20px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                    border-radius: 10px;
                  }

    .button-yellow {
        background: #fbb221;
        border: none;
        padding: 10px 500px;
        text-decoration: none;
        font-size: 14px;
        cursor: pointer;
        border-radius: 10px;
        margin-left: 130px;
        }
</style>

<?php

include "header.html";

$conn = mysqli_connect("localhost", "root", "", "kworldkaraoke");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Loop through each row of data and update the database
    foreach ($_POST["data"] as $row) {
        $id = $_GET['id'];
        $name = mysqli_real_escape_string($conn, $row["name"]);
        $pswd = mysqli_real_escape_string($conn, $row["pswd"]);
        $pnum = mysqli_real_escape_string($conn, $row["pnum"]);

        $sql = "UPDATE users SET user_name='$name', user_pswd='$pswd', user_pnum='$pnum' WHERE user_id='$id'";
        mysqli_query($conn, $sql);
        echo "<div class='popup'>";
          echo "<script> alert('Data saved!')</script>";
        echo "</div>";
    }
}

// Query the database
$id = $_GET['id'];
$sql = "SELECT user_id, user_name, user_pswd, user_pnum FROM users WHERE user_id='$id'";
$result = mysqli_query($conn, $sql);

echo "<div>";
echo "<h1 style='font-family: Copperplate; text-align:center;'>Update Information</h1>";
echo "<form action='admin_list.php' method='post' style='display:inline-block; text-align: center;'>";
echo"<input type='submit' name='approve' value='Back' class='button-yellow' style='padding: 10px 20px;'/>";
echo "</div>";

// Create the HTML table and form
echo "<form method='post'>";
echo "<table border='1' style='width: 80%;border-collapse: collapse; margin-left:auto;margin-right:auto;'>";
echo "<tr style='color: #FFDB58; background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);'>";
echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Admin ID</th>";
echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Name</th>";
echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Password</th>";
echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Phone Number</th>";
echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Action</th>";
echo "</tr>";

while($row = mysqli_fetch_array($result))
{
    echo "<tr>";
    echo "<td style='padding: px; border: 1px solid #ddd; text-align: center;'>" . $row['user_id'] . "</td>";
    echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;' contenteditable='true'><input type='text' name='data[" . $row['user_id'] . "][name]' value='" . htmlspecialchars($row['user_name']) . "'></td>";
    echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;' contenteditable='true'><input type='text' name='data[" . $row['user_id'] . "][pswd]' value='" . htmlspecialchars($row['user_pswd']) . "'></td>";
    echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;' contenteditable='true'><input type='text' name='data[" . $row['user_id'] . "][pnum]' value='" . htmlspecialchars($row['user_pnum']) . "'></td>";
    echo"<td style='padding: 8px; border: 1px solid #ddd; text-align: center;' contenteditable='true'><input type='submit' name='approve' value='Save' class='button-yellow' style='padding: 10px 20px;'/></td>";
    echo "</tr>";
}

echo "</table>";
echo "</form>";
echo "<br>";

// Close the connection
mysqli_close($conn);
include "footer.html";
?>