<?php

include('db.php');
include("../login/session.php");

if (!isset($_SESSION['user_name'])) {
    // Handle the case when the 'user_name' key is not set in the session
}

$user_name = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">
<style>
table {

  width: 70%;
  background-color: #ffffff;
  border-collapse: collapse;
  border-width: 2px;
  border-color: #d270c0;
  border-style: solid;
  color: #000000;
  align:center;
}

 td,  th {
text-align:center;
  border-width: 2px;
  border-color: #0F172B;;
  border-style: solid;
  padding: 3px;
}

 thead {
  background-color: #FEA116;;
}

.center {
  margin-left: auto;
  margin-right: auto;
}


</style>
<h2><center>Room List</h2>

<body bgcolor="#EEFDEF">

<?php

  $sqlUSER = "SELECT * FROM users where user_name = '$user_name' ";
  $queryUSER = mysqli_query($connection, $sqlUSER) or die ("Error: " . mysqli_error());
  $rowUSER = mysqli_num_rows($queryUSER);
  $rUSER= mysqli_fetch_assoc($queryUSER);

    //list rooms 
    $q="select * from room group by room_no asc";
    $res=mysqli_query($connection,$q);
  
    
    echo "<table border=2 align=center>\n\n";
    echo "<thead><tr><th>Room Number</th><th>Room Type</th><th>Price</th><th>Book</th></tr></thead>\n";
    while($r=mysqli_fetch_array($res)){
        echo "<tr><td>".$r['room_no']."</td><td>".$r['room_type']."</td><td>".$r['room_price']."</td><td><a href=reservation_slot.php?id=".$r['room_id']."&mydate=".date("Y-m-d").">Reserve</a></td></tr>\n";
    }
    echo "</table><br><br>";

?>
</body>
</html>