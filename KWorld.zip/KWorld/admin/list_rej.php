                     <style>
                  .button-purple {
                    background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
                    border: none;
                    color: white;
                    padding: 10px 20px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                    border-radius: 10px;
                  }

                  table {
                    width: 70%;
                    background-color: #ffffff;
                    border-collapse: collapse;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                    color: #000000;
                    align:center;
                  }

                   td, th {
                    text-align:center;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                  }

                   thead {
                    background-color: #FEA116;;
                  }

                  .center {
                    margin-left: auto;
                    margin-right: auto;
                  }


                </style>

                  <?php
                  include_once "db.php";
                  include_once "header.html";
                  echo "<br>";

                  echo "<h1 style='font-family: Copperplate; text-align:center; color: #FEA1160;'>Reservation List</h1>";

                  echo "<div style='text-align:center; padding: 5px;'>";
                    echo "<form action='list_pen.php' method='post' style='display:inline-block;'>";
                      echo "<input type='submit' name='approve' value='Pending' class='button-purple'/>";
                    echo "</form>";
                    echo "<form action='list_acc.php' method='post' style='display:inline-block;'>";
                      echo "<input type='submit' name='approve' value='Accepted' class='button-purple'/>";
                    echo "</form>";
                    echo "<form action='list_rej.php' method='post' style='display:inline-block;'>";
                      echo "<input type='submit' name='approve' value='Rejected' class='button-purple'/>";
                    echo "</form>";
                  echo "</div>";
                  echo "<br>";

                  $query = "SELECT * FROM reservation NATURAL JOIN room WHERE approval = 0 ORDER BY reserve_date DESC";
                  $result=mysqli_query($connection, $query);

                  $i = 1; //counter for the checkboxes so that each has a unique name
                  echo "<form action='reservation_process.php' method='post'>"; //form started here
                  echo "<table border='1' style='width: 95%; margin-left:auto;margin-right:auto;'border-collapse: collapse;'>";
                  echo "<tr style='color: #FFDB58; background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);'>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Reservation Date</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Reservation ID</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Room ID</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>User ID</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Slot ID</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Total Price</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Approval</th>";
                  echo "</tr>";

                  while($row = mysqli_fetch_array($result))
                  {
                      echo "<tr>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['reserve_date'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['reservation_id'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['room_id'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_id'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['slot_id'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['room_price'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'><i style='color: #AA0000;'>rejected</i></td>";
                      echo "</tr>";
                      $i++;
                  }
                  echo "</table>";
                  echo "<br><br>";
                  echo "</form>";

                  mysqli_close($connection);

                  ?>
                  <?php
                  include_once "footer.html";
                  ?>