                  <head>
                  <!-- Add icon library -->
                  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

                  <style>


                    .button-purple {
                    background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
                    border: none;
                    color: white;
                    padding: 10px 20px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                    border-radius: 10px;
                  }

                  .button-yellow {
                    background: #fbb221;
                    border: none;
                    padding: 10px 500px;
                    text-decoration: none;
                    font-size: 14px;
                    cursor: pointer;
                    border-radius: 10px;
                    margin-left: 130px;

                  }

                  table {
                    width: 70%;
                    background-color: #ffffff;
                    border-collapse: collapse;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                    color: #000000;
                    align:center;
                  }

                   td, th {
                    text-align:center;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                  }

                   thead {
                    background-color: #FEA116;;
                  }
                </style>
              </head>

              <body>
                  <?php

                  include "db.php";
                  include "header.html";

                  echo "<h1 style='font-family: Copperplate; text-align:center;'>Manage User's Information: Admin</h1>";

                  echo "<div style='text-align:center; padding: 5px;'>";
                    echo "<form action='admin_list.php' method='post' style='display:inline-block;'>";
                      echo "<input type='submit' name='approve' value='Admin' class='button-purple'/>";
                    echo "</form>";
                    echo "<form action='cust_list.php' method='post' style='display:inline-block;'>";
                      echo "<input type='submit' name='approve' value='Customer' class='button-purple'/>";
                    echo "</form>";
                  echo "</div>";

                  echo "<form action='admin_add.html' method='post' style='display:inline-block; text-align: center;'>";
                    echo"<input type='submit' name='approve' value='Add Admin' class='button-yellow' style='padding: 10px 20px;'/>";
                  echo "</form>";

                  $query = "SELECT * FROM users WHERE level_id = 1";
                  $result=mysqli_query($connection, $query);

                  $i = 1; //counter for the checkboxes so that each has a unique name
                  echo "<form action='reservation_process.php' method='post'>"; //form started here

                  echo "<table border='1' style='width: 80%;border-collapse: collapse; margin-left:auto;margin-right:auto;'>";
                  echo "<tr style='color: #FFDB58; background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);'>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Admin ID</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Name</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Password</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Phone Number</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Action</th>";
                  echo "</tr>";

                  while($row = mysqli_fetch_array($result))
                  {
                      echo "<tr>";
                      echo "<td style='padding: px; border: 1px solid #ddd; text-align: center;'>" . $row['user_id'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_name'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_pswd'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['user_pnum'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>";
                        echo "<a href='admin_del.php?id=".$row['user_id']."'><i class='fa fa-trash'></i></a>";
                        echo "<a href='admin_ed.php?id=".$row['user_id']."' style='margin-left: 8px;'><i class='fa fa-edit'></i></a>";
                      echo "</td>";
                      echo "</tr>";
                      $i++;
                  }

                  echo "</table>";
                  echo "</form>";
                  echo "<br>";

                  mysqli_close($connection);

                  include "footer.html";

                  ?>
                </body>
