                 <style>
                  .button-purple {
                    background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
                    border: none;
                    color: white;
                    padding: 10px 20px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                    border-radius: 10px;
                  }

                  table {
                    width: 70%;
                    background-color: #ffffff;
                    border-collapse: collapse;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                    color: #000000;
                    align:center;
                  }

                   td, th {
                    text-align:center;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                  }

                   thead {
                    background-color: #FEA116;;
                  }

                  .center {
                    margin-left: auto;
                    margin-right: auto;
                  }


                </style>

                  <?php

                  $query = "SELECT * FROM room ORDER BY room_no ASC";
                  $result=mysqli_query($connection, $query);

                  echo "<h1 style='font-family: Copperplate; text-align:center;'>Room List</h1>";

                  echo "<form action='room_mang.php' method='post'>"; //form started here
                  echo "<table border='1' style='width: 95%; margin-left:auto;margin-right:auto;'border-collapse: collapse;'>";
                  echo "<tr style='color: #FFDB58; background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);'>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Room Number</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Room Type</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Room Price</th>";
                  echo "</tr>";

                  while($row = mysqli_fetch_array($result))
                  {
                      echo "<tr>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['room_no'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['room_type'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['room_price'] . "</td>";
                      echo "</tr>";
                  }
                  echo "</table>";
                  echo "<br>";

                  $query2 = "SELECT * FROM slot";
                  $result2=mysqli_query($connection, $query2);

                  echo "<h1 style='font-family: Copperplate; text-align:center;'>Slot List</h1>";

                  echo "<table border='1' style='width: 95%; margin-left:auto;margin-right:auto;'border-collapse: collapse;'>";
                  echo "<tr style='color: #FFDB58; background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);'>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Slot ID</th>";
                  echo "<th style='padding: 8px; border: 1px solid #ddd; text-align: center;'>Slot</th>";
                  echo "</tr>";

                  while($row = mysqli_fetch_array($result2))
                  {
                      echo "<tr>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['slot_id'] . "</td>";
                      echo "<td style='padding: 8px; border: 1px solid #ddd; text-align: center;'>" . $row['slot'] . "</td>";
                  }
                  echo "</table>";
                  echo "</form>";
                  echo "<br>";

                  mysqli_close($connection);

                  ?>