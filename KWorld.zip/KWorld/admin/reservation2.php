<?php
include_once "db.php";
session_start();

include_once "header.html";
echo "<br>";
include_once "reservation_ver.php";

include_once "footer.html";
?>