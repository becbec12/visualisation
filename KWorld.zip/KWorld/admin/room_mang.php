<?php

    // Create connection
    $conn = mysqli_connect("localhost","root","","kworldkaraoke");
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $room_no = $_POST['room_no'];
        $room_type = $_POST['room_type'];
        $room_price = $_POST['room_price'];

        // Create the room ID by concatenating the values of $room_type and $room_no
        if ($room_type == "standard") $type = 'S';
        if ($room_type == "deluxe") $type = 'D';
        if ($room_type == "vip") $type = 'V';
        $room_id = $type . '1' . $room_no;

        $sql = "INSERT INTO room (room_id, room_no, room_type, room_price)
        VALUES ('$room_id', '$room_no', '$room_type', '$room_price')";

        if ($conn->query($sql) === TRUE) {
            // Display a pop-up message after the data has been successfully updated
    echo "<script>alert('Data has been successfully saved!'); window.location.href='reservation2.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();
?>