<?php
// Connect to your database
$conn = mysqli_connect("localhost","root","","kworldkaraoke");

// Check if the form has been submitted
if(isset($_POST['approve']) || isset($_POST['reject'])) {
    // Get the value of the checkbox that was checked
    $checkbox = $_POST['check'];

    // Loop through each checkbox value and update the 'approval' attribute accordingly
    foreach($checkbox as $id => $value) {
        echo "id: " . $id . "<br>";
        echo "value: " . $value . "<br>";

        if(isset($_POST['approve'])) {
            $approval = 1;
        } else if(isset($_POST['reject'])) {
            $approval = 0;
        }

        // Update the 'approval' attribute in your database table 'reservation'
        $query = "UPDATE reservation SET approval = '$approval' WHERE reservation_id = '$value'";
        mysqli_query($conn, $query);

    }
}

// Display a pop-up message after the data has been successfully updated
    echo "<script>alert('Data has been successfully saved!'); window.location.href='reservation2.php';</script>";

// Close your database connection
mysqli_close($conn);
?>
