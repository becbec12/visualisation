<?php
include_once "db.php";
session_start();

include_once "header.html";
?>

<style>
                  .button-purple {
                    background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
                    border: none;
                    color: white;
                    padding: 10px 20px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                    border-radius: 10px;
                  }

                  table {
                    width: 70%;
                    background-color: #ffffff;
                    border-collapse: collapse;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                    color: #000000;
                    align:center;
                  }

                   td, th {
                    text-align:center;
                    border-width: 2px;
                    border-color: black;
                    border-style: solid;
                  }

                   thead {
                    background-color: #FEA116;;
                  }

                  .center {
                    margin-left: auto;
                    margin-right: auto;
                  }


                </style>

<h1 style="font-family: Copperplate; text-align:center; color: #FEA1160;">Manage User's Information</h1>

<div style="text-align:center; padding: 5px;">
  <form action="admin_list.php" method="post" style="display:inline-block;">
    <input type="submit" name="approve" value="Admin" class="button-purple"/>
  </form>
  <form action="cust_list.php" method="post" style="display:inline-block;">
    <input type="submit" name="approve" value="Customer" class="button-purple"/>
  </form>
</div>
<br>

<?php
include_once "footer.html";
?>