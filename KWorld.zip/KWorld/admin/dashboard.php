<?php
include "header.html";
?>

<body>
	<div class="container-fluid booking pb-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container">
			  <div class="bg-white shadow" style="padding: 35px;">
				<div class="col-sm-9 col-sm-offset-3 col-lg-12 col-lg-offset-2 main">
					<div class="row">
						<ol class="breadcrumb">
							<li><a href="#">
								<em class="fa fa-home"></em><br>
							</a></li>
						</ol>
					</div><!--/.row-->
					
					<div class="row">
						<div class="col-lg-12">
							<h1 class="page-header">Dashboard</h1><br>
						</div>
					</div>
					
					<div class="panel panel-container">
						<div class="row">
							<div class="col-xs-8 col-md-6 col-lg-4 no-padding">
								<div class="mx-auto" style="width: 200px;">
									<div class="panel panel-teal panel-widget border-right">
										<div class="row no-padding"><em class="fa fa-xl fa-bed color-blue"></em>
											<div class="large"><?php include 'counters/room-count.php'?></div>
											<div class="text-muted">Total Rooms</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-8 col-md-6 col-lg-4 no-padding">
								<div class="mx-auto" style="width: 200px;">
									<div class="panel panel-blue panel-widget border-right">
										<div class="row no-padding"><em class="fa fa-xl fa-bookmark color-orange"></em>
											<div class="large"><?php include 'counters/reserve-count.php'?></div>
											<div class="text-muted">Reservations</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xs-8 col-md-6 col-lg-4 no-padding">
								<div class="mx-auto" style="width: 200px;">
									<div class="panel panel-orange panel-widget border-right">
										<div class="row no-padding"><em class="fa fa-xl fa-users color-teal"></em>
											<div class="large"><?php include 'counters/staff-count.php'?></div>
											<div class="text-muted">Admin</div>
										</div>
									</div>
								</div>
							</div>
							<!--/.row-->

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
							<!--/.row-->

						<hr>

						<div class="row">
							<div class="col-xs-6 col-md-2 col-lg-2 no-padding">
								
							</div>
					
				</div>	<!--/.main-->
	

		
</body>
</html>

<?php
include "footer.html";
?>