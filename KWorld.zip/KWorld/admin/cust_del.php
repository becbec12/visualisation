<?php
// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "kworldkaraoke");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the ID parameter is set in the URL
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // Delete the row from the database
    $sql = "DELETE FROM users WHERE user_id='$id'";
    mysqli_query($conn, $sql);

    // Redirect back to the main page
    header("Location: cust_list.php");
}

// Close the database connection
mysqli_close($conn);
?>
