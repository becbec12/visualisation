<?php
//connect to db
$dbconn=mysqli_connect('localhost','root','','vanbooking') or die(mysqli_error($dbconn));

//construct and run query to list vans
$q="select * from room";
$res=mysqli_query($dbcnon,$q);
while($r=mysqli_fetch_assoc($res)){
    $json[]=$r;
}
echo json_encode($json,JSON_UNESCAPED_UNICODE);
mysqli_free_result($res);
mysqli_close($dbconn);
?>