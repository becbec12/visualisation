<?php

//connect to db
$dbconn=mysqli_connect('localhost','root','','kworldkaraoke') or die(mysqli_error($dbconn));

//$q="SELECT * FROM (SELECT * FROM journey where (jdate='$mydate' and van_id=$van_id and (approval=1 or approval is null))) a right join(select * from seat) b on a.seat_id=b.id";
$q="select a.reservation_id, a.reserve_date, a.rmade_time, b.room_no, b.room_type c.slot, d.user_fname from reservatio a, room b, slot c, users d where a.approval is null and b.room_id=a.room_id and c.slot_id=a.slot_id and d.user_id=a.user_id order by reserve_date, rmade_time asc";
//echo $q;
$res=mysqli_query($dbconn,$q);
while($r=mysqli_fetch_assoc($res)){
    $json[]=$r;
}
echo json_encode($json,JSON_UNESCAPED_UNICODE);

//clear results and close the connection
mysqli_free_result($res);
mysqli_close($dbconn);

?>