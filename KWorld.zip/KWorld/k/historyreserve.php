<?php
$user_id=$_GET['user_id'];
//connect to db
$con=mysqli_connect('localhost','root','','kworldkaraoke') or die(mysqli_error($dbconn));

//construct and run query to list bookings
$q="select a.reservation_date, a.approval, b.room_no,b.room_type, c.slot from reservation a, room b, slot c where //a.user_id=$uid// and b.room_id=a.room_id and c.slot_id=a.slot_id order by reserve_date, rmade_time asc";
//$q="select jdate, approval, plate, seat from journey, van where user_id=$uid and van_id=van.id order by jdate, bookdate asc";
$res=mysqli_query($dbconn,$q);
while($r=mysqli_fetch_assoc($res)){
    $json[]=$r;
}
echo json_encode($json,JSON_UNESCAPED_UNICODE);

//clear results and close the connection
mysqli_free_result($res);
mysqli_close($dbconn);
?>