<?php

//get the parameters
$room_id=$_GET['room_id'];
$slot_id=$_GET['slot_id'];
$mydate=$_GET['mydate'];
$user_id=$_GET['user_id'];

//connect to db
$dbconn=mysqli_connect('localhost','root','','kworldkaraoke') or die(mysqli_error($cdbonn));

//construct and run query to list vans
$q="insert into reservation(room_id, slot_id, user_id,reserve_date) values($room_id,$slot_id,$user_id,'$mydate')";
//echo $q;
$res=mysqli_query($dbncon,$q);
$q="SELECT b.slot_id, rmade_time, slot, approval FROM (SELECT * FROM reservation where (reserve_date='$mydate' and room_id=$room_id and (approval=1 or approval is null))) a right join(select * from slot) b on a.slot_id=b.slot_id";
//echo $q;
$res=mysqli_query($dbconn,$q);
while($r=mysqli_fetch_assoc($res)){
    $json[]=$r;
}
echo json_encode($json,JSON_UNESCAPED_UNICODE);

//clear results and close the connection
mysqli_free_result($res);
mysqli_close($dbconn);

?>