<?php
//connect to db
$dbconn=mysqli_connect('localhost','root','','kworldkaraoke') or die(mysqli_error($dbconn));

$room_id=$_GET['room_id'];

//construct and run query to list vans
$q="select room_no from room where room_id=$room_id";
$res=mysqli_query($dbconn,$q);
$r=mysqli_fetch_assoc($res);

echo json_encode($r,JSON_UNESCAPED_UNICODE);
mysqli_free_result($res);
mysqli_close($dbconn);
?>