<?php

//get the parameter
$username=$_GET['username'];

//connect to db
$dbconn=mysqli_connect('localhost','root','','kworldkaraoke') or die(mysqli_error($dbconn));

$q="SELECT user_name,user_id,user_fname,user_pswd,level_id from users where user_name='$username'";
//echo $q;
$res=mysqli_query($dbconn,$q);
$r=mysqli_fetch_assoc($res);

echo json_encode($r,JSON_UNESCAPED_UNICODE);

//clear results and close the connection
mysqli_free_result($res);
mysqli_close($dbconn);

?>