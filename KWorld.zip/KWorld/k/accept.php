<?php

//get the parameters
$reservation_id=$_GET['reservation_id'];
$user_id=$_GET['user_id'];

//connect to db
$con=mysqli_connect('localhost','root','','kworldkaraoke') or die(mysqli_error($dbconn));

//construct and run query to list room
$q="update reservation set approval=1, admin_id=$user_id where reservation_id=$reservation_id";
//echo $q;
$res=mysqli_query($dbconn,$q);
$q="select a.reservation_id, a.reserve_date, a.rmade_time, b.room_no, b.room_type, c.slot, d.user_fname from reservation a, room b, slot c, users d where a.approval is null and b.room_id=a.room_id and c.slot_id=a.slot_id and d.user_id=a.user_id order by reserve_date, rmade_time asc";
//echo $q;
$res=mysqli_query($dbconn,$q);
while($r=mysqli_fetch_assoc($res)){
    $json[]=$r;
}
echo json_encode($json,JSON_UNESCAPED_UNICODE);

//clear results and close the connection
mysqli_free_result($res);
mysqli_close($dbconn);

?>