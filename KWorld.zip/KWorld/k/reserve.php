<?php

//get the parameter
$room_id=$_GET['room_id'];
$mydate=$_GET['mydate'];
//$van_id=2;
//$mydate='2022-06-14';

//connect to db
$dbconn=mysqli_connect('localhost','root','','kworldkaraoke') or die(mysqli_error($dbconn));

$q="SELECT b.slot_id, rmade_time, slot, approval FROM (SELECT * FROM reservation where (reserve_date='$mydate' and room_id=$room_id and (approval=1 or approval is null))) a right join(select * from slot) b on a.slot_id=b.slot_id";
//echo $q;
$res=mysqli_query($dbconn,$q);
while($r=mysqli_fetch_assoc($res)){
    $json[]=$r;
}
echo json_encode($json,JSON_UNESCAPED_UNICODE);

//clear results and close the connection
mysqli_free_result($res);
mysqli_close($dbconn);

?>