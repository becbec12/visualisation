<?php
// Inialize session
session_start();

// Include database connection settings
include('../include/dbconn.php');

if(isset($_POST['login'])){
	
	/* capture values from HTML form */
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$sql= "SELECT user_id,user_name, user_pswd, level_id FROM users WHERE user_name= '$username' AND user_pswd = '$password'";
	$query=mysqli_query($dbconn,$sql) or die("Error:".mysqli_error());
    $row = mysqli_num_rows($query);

	if($row == 0){
	 // Jump to indexwrong page
	header('Location: indexwrong.html'); 
	}
	else{
	 $r = mysqli_fetch_assoc($query);
	 $username= $r['username'];
	 //$username= $r['email'];
	 $password= $r['password'];
	 $level= $r['level_id'];
	 //echo($level_id);
	
		if($level==1) { 
			$_SESSION['username'] = $r['username'];
			$_SESSION['user_id'] = $r['user_id'];
			$_SESSION['level_id'] = $level;
			// Jump to secured page
			header('Location: ../admin/dashboard.php'); 
		} 
		elseif($level==2) {
			$_SESSION['username'] = $r['username'];
			$_SESSION['user_id'] = $r['user_id'];
			$_SESSION['level_id'] = $level;


			// Jump to secured page
			header('Location: ../customer.html');
		}
		else {
			header('Location: index.html');
			echo($level);
		}
		
	}	
}
mysqli_close($dbconn);
?>

