<?php

session_start();
include('../include/dbconn.php');
include ("../login/session.php");
$user_name = $_SESSION['username'];

if (!isset($_SESSION['username'])) {

            } 

// Query reservations for current user
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>K WORLD CUSTOMER</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="bootstrap1.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="style1.css" rel="stylesheet">

    <style>
        .button-purple {
                    background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
                    border: none;
                    color: white;
                    padding: 5px 10px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                    border-radius: 10px;
                  }

        .button-yellow {
                    background: #fbb221;
                    border: none;
                    padding: 5px 10px;
                    text-decoration: none;
                    font-size: 14px;
                    cursor: pointer;
                    border-radius: 10px;
                    margin-left: 10px;

                  }
    </style>
</head>

<body>
    
        <!-- Spinner End -->

        <!-- Header Start -->
        <div class="container-fluid bg-dark px-0">
            <div class="row gx-0">
                <div class="col-lg-3 bg-dark d-none d-lg-block">
                    <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                        <h1 class="m-0 text-primary text-uppercase">K WORLD</h1>
                    </a>
                </div>
                <div class="col-lg-9">
                    <div class="row gx-0 bg-white d-none d-lg-flex">
                        <div class="col-lg-7 px-5 text-start">
                            <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                                <i class="fa fa-envelope text-primary me-2"></i>
                                <p class="mb-0">kworld@gmail.com</p>
                            </div>
                            <div class="h-100 d-inline-flex align-items-center py-2">
                                <i class="fa fa-phone-alt text-primary me-2"></i>
                                <p class="mb-0">+011 1166 0987</p>
                            </div>
                        </div>
                        <div class="col-lg-5 px-5 text-end">
                        </div>
                    </div>
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                        <a href="index.php" class="navbar-brand d-block d-lg-none">
                            <h1 class="m-0 text-primary text-uppercase">K WORLD KARAOKE</h1>
                        </a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto py-0">
                                <a href="../customer.html" class="nav-item nav-link ">Home</a>
                                <a href="update_profile.php" class="nav-item nav-link">Profile</a>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle " data-bs-toggle="dropdown">Pages</a>
                                    <div class="dropdown-menu rounded-0 m-0">
                                        <a href="room_details.html" class="dropdown-item ">Room Details</a>
                                        <a href="viewroom.php" class="dropdown-item">Make a Reservation</a>
                                        <a href="rhistory.php" class="dropdown-item">Reservation History</a>
                                    </div>
                                </div>
                             </div>
                             <a href="../login/index.html" class="btn btn-primary rounded-0 py-4 px-md-5 d-none d-lg-block">Log Out <i class="fa fa-arrow-right ms-3"></i></a>                        
                         </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Header End -->

        <h1 style="text-align:center; background-color: #333; color: #FFDB58;">Reservation List</h1>

        <style>

        .button-purple {
            background: linear-gradient(89.9deg, rgb(102, 64, 123) 0%, rgb(252, 41, 119) 100%, rgb(251, 168, 214) 100.1%);
            border: none;
            color: white;
            padding: 8px 15px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 10px;
            }

        table {
            width: 70%;
            background-color: #ffffff;
            border-collapse: collapse;
            border-width: 2px;
            border-color: black;
            border-style: solid;
            color: #000000;
            align:center;
                }

        td, th {
            text-align:center;
            border-width: 3px;
            border-color: black;
            border-style: solid;
                }

        thead {
            background-color: #FEA116;;
                }

        .center {
            margin-left: auto;
            margin-right: auto;
             }


        </style>




<?php

$rows_per_page = 10;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$start = ($page - 1) * $rows_per_page;


$user_id = $_SESSION['user_id'];

$query = "SELECT reservation_id, reserve_date, room_id, slot_id, approval, rmade_time
          FROM reservation
          WHERE user_id = '$user_id'
          ORDER BY reserve_date DESC";

$result = mysqli_query($dbconn, $query);

$i = 1; // Counter for the checkboxes so that each has a unique name
echo "<table border='2'  style='border-color: black;width: 95%; margin-left:auto;margin-right:auto;'border-collapse: collapse;'>";
echo "<tr style='background: linear-gradient(to bottom, #FFD35C, #4481EB);'>";
echo "<th style='padding: 8px; border: 1px solid #000000; text-align: center;'>Reservation ID</th>";
echo "<th style='padding: 8px; border: 1px solid #000000; text-align: center;'>Reservation Date</th>";
echo "<th style='padding: 8px; border: 1px solid #000000; text-align: center;'>Room ID</th>";
echo "<th style='padding: 8px; border: 1px solid #000000; text-align: center;'>Slot ID</th>";
echo "<th style='padding: 8px; border: 1px solid #000000; text-align: center;'>Approval</th>";
echo "<th style='padding: 8px; border: 1px solid #000000; text-align: center;'>Invoice</th>";
echo "</tr>";

while ($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td style='padding: 8px; border: 1px solid #000000; text-align: center;'>" . $row['reservation_id'] . "</td>";
    echo "<td style='padding: 8px; border: 1px solid #000000; text-align: center;'>" . $row['reserve_date'] . "</td>";
    echo "<td style='padding: 8px; border: 1px solid #000000; text-align: center;'>" . $row['room_id'] . "</td>";
    echo "<td style='padding: 8px; border: 1px solid #000000; text-align: center;'>" . $row['slot_id'] . "</td>";

    echo "<td style='padding: 8px; border: 1px solid #000000; text-align: center;'>";
    if ($row['approval'] == 1) {
    echo '<span class="badge bg-success">Approved</span>';
    } elseif ($row['approval'] === null) {
        echo '<span class="badge bg-warning text-dark">Pending</span>';
    } elseif ($row['approval'] == 0) {
        echo '<span class="badge bg-danger">Rejected</span>';
    } else {
        echo '<span class="badge bg-secondary">Unknown</span>';
    }

    echo "<td style='padding: 8px; border: 1px solid #000000; text-align: center;'>";
    echo "<form method='get' action='invoice.php'>";
    echo "<input type='hidden' name='id' value='".$row['reservation_id']."'>";
    echo "<input class='button-purple' type='submit' name='invoice' value='Invoice'>";
    echo "</form>";
    echo "</td>";
}
echo "</td>";
echo "</table>";
echo "<br><br>";
echo "</form>";

mysqli_close($dbconn);
?>

<!-- Footer Start -->
        <!-- Footer Start -->
<br><br><br>
<div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
    <div class="container pb-5">
        <div class="row g-0.5">
            <div class="col-md-6 col-lg-4">
                <div class="bg-primary rounded p-4">
                    <a href="index.php"><h1 class="text-white text-uppercase mb-3">K WORLD</h1></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>K-World Amanjaya Mall, Aras 2, 0800 Sungai Petani, Kedah, Malaysia</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+011 1166 0987</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>kworld@gmail.com</p>
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="row gy-5 g-4">
                    <div class="col-md-6">
                        <br>
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                        <a class="btn btn-link" href="">About Us</a>
                        <a class="btn btn-link" href="">Contact Us</a>
                        <a class="btn btn-link" href="">Privacy Policy</a>
                        <a class="btn btn-link" href="">Terms & Condition</a>
                        <a class="btn btn-link" href="">Support</a>
                    </div>
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                        <a class="btn btn-link" href="">Karaoke Equipment</a>
                        <a class="btn btn-link" href="">Foods & Drinks</a>
                        <a class="btn btn-link" href="">Event & Party</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; <a class="border-bottom" href="#">K World Sdn. Bhd.</a>, All Right Reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->
        <!-- Footer End -->
        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

</body>
</html>
