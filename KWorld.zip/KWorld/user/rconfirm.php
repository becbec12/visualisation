<?php
session_start();
include('../include/dbconn.php');
include ("../login/session.php");
if(isset($_SESSION['user_id'])){

    //get the parameters
    $room_id=$_GET['room_id'];
    $slot_id=$_GET['slot_id'];
    $mydate=$_GET['date'];
    $user_id=$_SESSION['user_id'];

    //construct and run query to list vans
    $q="insert into reservation(room_id, slot_id, user_id,reserve_date) values('$room_id','$slot_id','$user_id','$mydate')";
    //echo $q;
    $res=mysqli_query($dbconn,$q);
    echo "<script> alert('Your data has been saved succesfully');window.location='viewroom.php'</script>";

    //clear results and close the connection
    //mysqli_free_result($res);
    mysqli_close($dbconn);
}else{ echo "<h1>Error</h1>";
echo "Userid : ".$_SESSION['user_id'];
echo "<br>Level id : ".$_SESSION['level_id'];
}
?>