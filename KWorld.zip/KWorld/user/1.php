<?php

include('../include/dbconn.php');
include ("../login/session.php");
session_start();
if (!isset($_SESSION['username'])) {
       // header('Location: ../login');
        } 


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>K WORLD CUSTOMER</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="bootstrap1.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="style1.css" rel="stylesheet">
</head>

<body>
    
        <!-- Spinner End -->

        <!-- Header Start -->
        <div class="container-fluid bg-dark px-0">
            <div class="row gx-0">
                <div class="col-lg-3 bg-dark d-none d-lg-block">
                    <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                        <h1 class="m-0 text-primary text-uppercase">K WORLD</h1>
                    </a>
                </div>
                <div class="col-lg-9">
                    <div class="row gx-0 bg-white d-none d-lg-flex">
                        <div class="col-lg-7 px-5 text-start">
                            <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                                <i class="fa fa-envelope text-primary me-2"></i>
                                <p class="mb-0">kworld@gmail.com</p>
                            </div>
                            <div class="h-100 d-inline-flex align-items-center py-2">
                                <i class="fa fa-phone-alt text-primary me-2"></i>
                                <p class="mb-0">+011 1166 0987</p>
                            </div>
                        </div>
                    </div>
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                        <a href="index.php" class="navbar-brand d-block d-lg-none">
                            <h1 class="m-0 text-primary text-uppercase">K WORLD: CUSTOMER PAGE</h1>
                        </a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto py-0">
                                <a href="index.php" class="nav-item nav-link">Home</a>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle active" data-bs-toggle="dropdown">Pages</a>
                                    <div class="dropdown-menu rounded-0 m-0">
                                        <a href="./user/viewroom.php" class="dropdown-item">Make a Reservation</a>
                                        <a href="../user/viewroom.php" class="dropdown-item active">Room Details</a>
                                        <a href="adminreservation.html" class="dropdown-item">Service Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div><br><br>
        <!-- Header End -->
        <style>
table {

  width: 30%;
  background-color: #ffffff;
  border-collapse: collapse;
  border-width: 2px;
  border-color: #0F172B;
  border-style: solid;
  color: #000000;
  align:center;
  }

 td,  th {
text-align:center;
  border-width: 2px;
  border-color: #0F172B;
  border-style: solid;
  padding: 3px;
}

 thead {
  background-color: #FEA116;;
}

input[type="date"] {
  background-color: #FEA116;;
  outline: none;
      top: 50%;
    left: 50%;
}

input[type="date"]::-webkit-clear-button {
  font-size: 18px;
  height: 30px;
  position: absolute;
}

input[type="date"]::-webkit-inner-spin-button {
  height: 28px;
}

input[type="date"]::-webkit-calendar-picker-indicator {
  font-size: 15px;
}


</style>
    <?php

    //get the parameter
    $room_id=$_GET['id'];
    $mydate=$_GET['mydate'];

    //construct and run query to list vans
    $q="select * from room where room_id='".$_GET['id']."'";
    $res=mysqli_query($dbconn,$q);
    $r=mysqli_fetch_assoc($res);
    echo "<h2>Room ".$r['room_no']."</h2>\n";
    echo "<p>".$r['room_type']."\n".$r['room_price']."\n".$mydate."</p>\n";
    echo "<form method=get action=reserveroom.php><input type=hidden name=id value=$room_id>"; //room type 
    echo "<input type=date align=center name=mydate><input type=submit></form>";

    $q="SELECT * FROM (SELECT * FROM reservation where (reserve_date='$mydate' and room_id='$room_id' and (approval=1 or approval is null))) a right join(select * from slot) b on a.slot_id=b.slot_id";

    //echo $q;

    $res=mysqli_query($dbconn,$q);
    echo "<table border=2 align=center>\n";
    echo "<thead><tr><th>Slot</th><th>Status</th><th>Action</th></tr></thead>\n";
    while($r=mysqli_fetch_assoc($res)){
        echo "<tr><td>".$r['slot']."</td><td>";
        if(($r['rmade_time']!=null)&&($r['approval']==1)) echo 'Reserved'; 
        elseif($r['rmade_time']!=null&&($r['approval']==0 or $r['approval']==NULL)) echo 'Pending <a href=rconfirm.php?room_id='.$room_id.'&slot_id='.$r['slot_id'].'&date='.$mydate.'></a>'; 
        else {
        echo 'Available '; 
        echo '<td><a href=rconfirm.php?room_id='.$room_id.'&slot_id='.$r['slot_id'].'&date='.$mydate.'><button name=\"book\" type=\"button\" value=\"book\">Book</button></a></td>';
    }
        echo "</td></tr>\n";
    }
    echo "</table>";

    //construct and run query to list users 

    //clear results and close the connection

?>

 <!-- Footer Start -->
        <br><br><br><div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
            <div class="container pb-5">
                <div class="row g-0.5">
                    <div class="col-md-6 col-lg-4">
                        <div class="bg-primary rounded p-4">
                            <a href="index.php"><h1 class="text-white text-uppercase mb-3">K WORLD</h1></a>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>K-World Amanjaya Mall, Aras 2, 0800 Sungai Petani, Kedah, Malaysia</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+011 1166 0987</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>kworld@gmail.com</p>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="row gy-5 g-4">
                            <div class="col-md-6">
                                <br>
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                                <a class="btn btn-link" href="">About Us</a>
                                <a class="btn btn-link" href="">Contact Us</a>
                                <a class="btn btn-link" href="">Privacy Policy</a>
                                <a class="btn btn-link" href="">Terms & Condition</a>
                                <a class="btn btn-link" href="">Support</a>
                            </div>
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                                <a class="btn btn-link" href="">Karaoke Equipment</a>
                                <a class="btn btn-link" href="">Foods & Drinks</a>
                                <a class="btn btn-link" href="">Event & Party</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="#">K World Sdn. Bhd.</a>, All Right Reserved.
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->
        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

</body>
</html>



    $res=mysqli_query($dbconn,$q);
    echo "<table border=2 align=center>\n";
    echo "<thead><tr><th>Slot</th><th>Status</th></tr></thead>\n";
    while($r=mysqli_fetch_assoc($res)){
        echo "<tr><td>".$r['slot']."</td><td>";
        if(($r['rmade_time']!=null)&&($r['approval']==1)) echo 'X'; 
        elseif($r['rmade_time']!=null&&($r['approval']==0 or $r['approval']==NULL)) echo 'A/B <a href=rconfirm.php?room_id='.$room_id.'&slot_id='.$r['slot_id'].'&date='.$mydate.'><button>Book</button></a>'; 
        else echo 'A <a href=rconfirm.php?room_id='.$room_id.'&slot_id='.$r['slot_id'].'&date='.$mydate.'><button>Book</button></a>';
        echo "</td></tr>\n";
    }
    echo "</table>";
