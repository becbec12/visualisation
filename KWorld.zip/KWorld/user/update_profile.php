<?php

session_start();
include('../include/dbconn.php');
include ("../login/session.php");
$user_name = $_SESSION['username'];

if (!isset($_SESSION['username'])) {

            } 

// Query reservations for current user
?>
<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>K WORLD CUSTOMER</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="bootstrap1.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="style1.css" rel="stylesheet">
        <title>Profile</title>

</head>

<body>
    
        <!-- Spinner End -->

<!-- Header Start -->
        <div class="container-fluid bg-dark px-0">
            <div class="row gx-0">
                <div class="col-lg-3 bg-dark d-none d-lg-block">
                    <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                        <h1 class="m-0 text-primary text-uppercase">K WORLD</h1>
                    </a>
                </div>
                <div class="col-lg-9">
                    <div class="row gx-0 bg-white d-none d-lg-flex">
                        <div class="col-lg-7 px-5 text-start">
                            <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                                <i class="fa fa-envelope text-primary me-2"></i>
                                <p class="mb-0">kworld@gmail.com</p>
                            </div>
                            <div class="h-100 d-inline-flex align-items-center py-2">
                                <i class="fa fa-phone-alt text-primary me-2"></i>
                                <p class="mb-0">+011 1166 0987</p>
                            </div>
                        </div>
                        <div class="col-lg-5 px-5 text-end">
                        </div>
                    </div>
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                        <a href="index.php" class="navbar-brand d-block d-lg-none">
                            <h1 class="m-0 text-primary text-uppercase">K WORLD KARAOKE</h1>
                        </a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto py-0">
                                <a href="../customer.html" class="nav-item nav-link ">Home</a>
                                <a href="update_profile.php" class="nav-item nav-link">Profile</a>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle " data-bs-toggle="dropdown">Pages</a>
                                    <div class="dropdown-menu rounded-0 m-0">
                                        <a href="room_details.html" class="dropdown-item ">Room Details</a>
                                        <a href="viewroom.php" class="dropdown-item">Make a Reservation</a>
                                        <a href="rhistory.php" class="dropdown-item">Reservation History</a>
                                    </div>
                                </div>
                             </div>
                             <a href="../login/index.html" class="btn btn-primary rounded-0 py-4 px-md-5 d-none d-lg-block">Log Out <i class="fa fa-arrow-right ms-3"></i></a>                        
                         </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Header End -->
		
    
    <style>

  .profile-container {
    max-width: 800px;
    margin-bottom: 40px;
    padding: 20px;
     background: linear-gradient(135deg, #f3be66, #9b59b6);
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin-left: auto;
    margin-right: auto;
    border-radius: 10px;
}

h2 {
    text-align: center;
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: inline-block;
    padding: 7px;
    border-radius: 4px;
    background: #D3EEF4;
    border: 2px solid transparent;
    background-clip: padding-box;
    color: #000;
    font-weight: bold;
    opacity: 0.8;
}

.form-group gender-label {
    display: inline-block;
    padding: 7px;
    border-radius: 4px;
    border: 2px solid transparent;
    background-clip: padding-box;
    color: #000;
    font-weight: bold;
}

.form-group label::after {
    content: "";
}

.form-group.required label::after {
    content: "*:";
    color: #FF0000;
}

.form-control {
    width: 100%;
    padding: 12px;
    border-radius: 4px;
    border: 1px solid #ccc;
    box-sizing: border-box;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

.form-control:focus {
    border-color: #00008B;
}

.input-box {
    text-align: center;
    margin-bottom: 20px;
}

.gender-title {
    display: block;
    font-size: 16px;
    color: #555;
    margin-bottom: 10px;
}

.category label {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}

.dot {
    display: inline-block;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    margin-right: 5px;
    vertical-align: middle;
}

.one {
    background-color: #D3EEF4;
}

.two {
    background-color: #00008B;
}

.gender {
            vertical-align: middle;
            font-weight: bold;
            font-size: 14px;
            color: #555;
        }


.button-update {
    text-align: center;
    margin-top: 20px;
}

input[type="submit"] {
    background-color: #D3EEF4;
    color: #fff;
    padding: 12px 24px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #1E90FF;
    transition: background-color 0.3s ease;
}

.name {
    font-size: 24px;
    font-weight: bold;
    text-align: center;
    margin-left: auto;
    color: #333;
    padding: 10px;
    border: 2px solid #ccc;
    border-radius: 5px;
    background-color: #F1EEC8;
}

.profile-content {
    align-items: center;
}



.profile-photo img {
	align-text: center;
    width: 100px; /* Adjust the width as needed */
    border-radius: 50%;
    /* Add any other styling properties */
}

.center {
  display: block;
  margin-left: 340px;
  margin-right: 100px;
  width: 50%;
  margin-top: 15px;

}




</style>
<?php

    // Establish a database connection
	// Retrieve the user ID (replace with your own code to get the user ID)
	if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id']; // Assuming you have stored the user ID in a session variable
	} elseif (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id']; // Assuming the user ID is passed as a parameter in the URL
	} else {
    // Handle the case when the user ID is not available
    echo "User ID is not provided.";
    exit; // Stop further execution or redirect to an error page
	}

	// Retrieve user data from the database based on the user ID (replace with your own code)
	$query = "SELECT * FROM users WHERE user_id = $user_id";
	$result = mysqli_query($dbconn, $query);
	$fetch = mysqli_fetch_assoc($result);

    // Check if the update_profile form is submitted
    if (isset($_POST['update_profile'])) {
        // Retrieve the form values
        $username = $_POST['username'];
        $userfname = $_POST['userfname'];
        $lastname = $_POST['lastname'];
        $userdob = $_POST['userdob'];
        $userphono = $_POST['userphono'];
        $password = $_POST['password'];
        $gender = $_POST['gender'];
		$level_id = '2';

        // Update the user profile in the database (Replace with your own code)
        $query = "UPDATE users SET user_name = '$username', user_fname = '$userfname', user_lname = '$lastname', user_dob = '$userdob', user_pnum = '$userphono', user_gender = '$gender', `level_id` = $level_id where user_id=user_id";
         mysqli_query($dbconn, $query);
         $query .= " WHERE user_id = $user_id";
    }

    // Close the database connection
    mysqli_close($dbconn);
?>
</head>
<body>

		<div class="profile-container">
		<h2>Profile</h2>
        <div class="name">
            <?php echo $fetch['user_fname']." ".$fetch['user_lname'] ?>
        </div>
        <div class="col-md-6 col-lg-3">
    <div class="profile-content">
        <div class="profile-photo" >
            <img src="../img/p1.png" alt="Profile Photo" class="center">
        </div>
        <!-- Profile information goes here -->
    </div>
</div>

        <div class="profile-info">
            <form method="POST" enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="form-group">
                    <input type="hidden" class="form-control" id="level_id" name="level_id" value="2">
                </div>
                <div class="form-group">
                    <label for="username">Username:</label>
                    <br><input type="text" class="form-control" id="username" name="username" value="<?php echo $fetch['user_name']; ?>">
                </div>
                <div class="form-group">
                    <label for="userfname">First Name:</label>
                    <input type="text" class="form-control" id="userfname" name="userfname" value="<?php echo $fetch['user_fname']; ?>">
                </div>
                <div class="form-group">
                    <label for="lastname">Last Name:</label>
                    <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $fetch['user_lname']; ?>">
                </div>
                <div class="form-group">
                    <label for="userdob">Date of Birth:</label>
                    <input type="date" class="form-control" id="userdob" name="userdob" value="<?php echo $fetch['user_dob']; ?>">
                </div>
                <div class="form-group">
                    <label for="userphono">Phone Number:</label>
                    <input type="text" class="form-control" id="userphono" name="userphono" value="<?php echo $fetch['user_pnum']; ?>">
                </div>
                <div class="form-group">
                    <label for="password">New Password:</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter new password" required>
                </div>
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <div class="radio">
                        <gender-label class="radio-inline"><input type="radio" name="gender" value="m" <?php if ($fetch['user_gender'] == 'm') echo 'checked'; ?>> Male</gender-label>
                        <gender-label class="radio-inline"><input type="radio" name="gender" value="f" <?php if ($fetch['user_gender'] == 'f') echo 'checked'; ?>> Female</gender-label>
                    </div>
                </div>
                <br><br>
                <div class="button-update">
                    <button type="submit" class="btn btn-primary" name="update_profile">Update Profile</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Footer Start -->
      <!-- Footer Start -->
<br><br><br>
<div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
    <div class="container pb-5">
        <div class="row g-0.5">
            <div class="col-md-6 col-lg-4">
                <div class="bg-primary rounded p-4">
                    <a href="index.php"><h1 class="text-white text-uppercase mb-3">K WORLD</h1></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>K-World Amanjaya Mall, Aras 2, 0800 Sungai Petani, Kedah, Malaysia</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+011 1166 0987</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>kworld@gmail.com</p>
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="row gy-5 g-4">
                    <div class="col-md-6">
                        <br>
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                        <a class="btn btn-link" href="">About Us</a>
                        <a class="btn btn-link" href="">Contact Us</a>
                        <a class="btn btn-link" href="">Privacy Policy</a>
                        <a class="btn btn-link" href="">Terms & Condition</a>
                        <a class="btn btn-link" href="">Support</a>
                    </div>
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                        <a class="btn btn-link" href="">Karaoke Equipment</a>
                        <a class="btn btn-link" href="">Foods & Drinks</a>
                        <a class="btn btn-link" href="">Event & Party</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                &copy; <a class="border-bottom" href="#">K World Sdn. Bhd.</a>, All Right Reserved.
            </div>
            <div class="col-md-6 text-center text-md-end">
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->

<!-- Back to Top -->
<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
</div>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/tempusdominus/js/moment.min.js"></script>
<script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
<script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>

</body>
</body>
</html>