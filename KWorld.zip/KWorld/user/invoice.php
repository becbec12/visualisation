<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>K WORLD CUSTOMER</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="bootstrap1.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="style1.css" rel="stylesheet">

    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>K WORLD CUSTOMER</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="bootstrap1.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="style1.css" rel="stylesheet">

    <style>
        .button-yellow {
                    background: #fbb221;
                    border: none;
                    padding: 5px 20px;
                    text-decoration: none;
                    font-size: 14px;
                    cursor: pointer;
                    border-radius: 10px;
                  }
    </style>
</head>

<body>
    
        <!-- Spinner End -->

        <!-- Header Start -->
        <div class="container-fluid bg-dark px-0">
            <div class="row gx-0">
                <div class="col-lg-3 bg-dark d-none d-lg-block">
                    <a href="index.php" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                        <h1 class="m-0 text-primary text-uppercase">K WORLD</h1>
                    </a>
                </div>
                <div class="col-lg-9">
                    <div class="row gx-0 bg-white d-none d-lg-flex">
                        <div class="col-lg-7 px-5 text-start">
                            <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                                <i class="fa fa-envelope text-primary me-2"></i>
                                <p class="mb-0">kworld@gmail.com</p>
                            </div>
                            <div class="h-100 d-inline-flex align-items-center py-2">
                                <i class="fa fa-phone-alt text-primary me-2"></i>
                                <p class="mb-0">+011 1166 0987</p>
                            </div>
                        </div>
                        <div class="col-lg-5 px-5 text-end">
                        </div>
                    </div>
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                        <a href="index.php" class="navbar-brand d-block d-lg-none">
                            <h1 class="m-0 text-primary text-uppercase">K WORLD KARAOKE</h1>
                        </a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto py-0">
                                <a href="../customer.html" class="nav-item nav-link ">Home</a>
                                <a href="update_profile.php" class="nav-item nav-link">Profile</a>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle " data-bs-toggle="dropdown">Pages</a>
                                    <div class="dropdown-menu rounded-0 m-0">
                                        <a href="room_details.html" class="dropdown-item ">Room Details</a>
                                        <a href="viewroom.php" class="dropdown-item">Make a Reservation</a>
                                        <a href="rhistory.php" class="dropdown-item">Reservation History</a>
                                    </div>
                                </div>
                             </div>
                             <a href="../login/index.html" class="btn btn-primary rounded-0 py-4 px-md-5 d-none d-lg-block">Log Out <i class="fa fa-arrow-right ms-3"></i></a>                        
                         </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Header End -->
</head>

<body>
<br><br>
    <div class="container-fluid booking pb-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container" style="margin: auto; padding-left: 300px;">
              <div class="bg-white shadow" style="padding: 35px; width: 550px;">
                <div class="col-sm-9 col-sm-offset-3 col-lg-19 col-lg-offset-2 main">
                    <div class="row">

    <?php
    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kworldkaraoke";
    $id=$_GET['id'];

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Select data from the table  
    $sql = "SELECT * FROM reservation NATURAL JOIN room NATURAL JOIN users NATURAL JOIN slot WHERE reservation_id=$id";
    $result = $conn->query($sql);

    echo "<form action='rhistory.php'>";
    echo "<input class='button-yellow' type='submit' name='invoice' value='Back'>";
    echo "</form>";
    echo "<br>";
    echo "<br>";
    echo "<h1>INVOICE</h1>";

    echo "<div style='font-family: Arial; font-size: 16px;'>";
    // Display data in a table
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<br>Reservation Number: ".$row['reservation_id']."<br>";
                    echo "Customer Name: ".$row['user_fname']." ".$row['user_lname']."";
                    echo "<br>Date: ".$row['reserve_date']."";
                    echo "<br>Time: ".$row['slot']."";
                    echo "<br>Room Number: ".$row['room_no']."";
                    echo "<br>Price: ".$row['room_price']."";
                    echo "<br>Room Type: ".$row['room_type']."";
                    if ($row['approval'] == 1) {
                        $a = "Approved";
                    }
                    if ($row['approval'] == 0) {
                        $a = "Rejected";
                    }
                    if ($row['approval'] === null) {
                        $a = "Pending";
                    }
                    echo "<br>Status: $a";
                    echo "<br>";
                }
            } else {
                echo "0 results";
        }

    // Close the connection
    $conn->close();
?>
</div>
</div>
</div>
</div>
</div>
<!-- Footer Start -->
        <!-- Footer Start -->
<br><br>
<div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
    <div class="container pb-5">
        <div class="row g-0.5">
            <div class="col-md-6 col-lg-4">
                <div class="bg-primary rounded p-4">
                    <a href="index.php"><h1 class="text-white text-uppercase mb-3">K WORLD</h1></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>K-World Amanjaya Mall, Aras 2, 0800 Sungai Petani, Kedah, Malaysia</p>
                <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+011 1166 0987</p>
                <p class="mb-2"><i class="fa fa-envelope me-3"></i>kworld@gmail.com</p>
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="row gy-5 g-4">
                    <div class="col-md-6">
                        <br>
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Company</h6>
                        <a class="btn btn-link" href="">About Us</a>
                        <a class="btn btn-link" href="">Contact Us</a>
                        <a class="btn btn-link" href="">Privacy Policy</a>
                        <a class="btn btn-link" href="">Terms & Condition</a>
                        <a class="btn btn-link" href="">Support</a>
                    </div>
                    <div class="col-md-6">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4"> </h6>
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Services</h6>
                        <a class="btn btn-link" href="">Karaoke Equipment</a>
                        <a class="btn btn-link" href="">Foods & Drinks</a>
                        <a class="btn btn-link" href="">Event & Party</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="copyright">
            <div class="row">
                <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                    &copy; <a class="border-bottom" href="#">K World Sdn. Bhd.</a>, All Right Reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->
        <!-- Footer End -->
        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

</body>
</html>
